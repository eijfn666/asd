package com.hunau;

import com.hunau.netty.NettyServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.net.InetSocketAddress;

/**
 * @author TanXY
 * @date 2020/12/29 20:24
 */
@SpringBootApplication
public class WebApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebApplication.class, args);
		NettyServer nettyServer = new NettyServer();
		nettyServer.start(new InetSocketAddress("192.168.137.1",5000));
	}

}
