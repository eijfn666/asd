package com.hunau.controller;

import com.hunau.domain.CollData;
import com.hunau.lang.DataTable;
import com.hunau.service.CollDataService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author TanXY
 * @date 2020/12/29 - 18:37
 */
@Controller
public class CollDataController {
    @Autowired
    CollDataService collDataService;


    @GetMapping("/index")
    public String collDataList() {
        return "/CollData/index";
    }

    @GetMapping("/showChart")
    public String showChaart() {
        return "chart";
    }

    @GetMapping("/collData/addCollData")
    public String addCollData() {
        return "/CollData/collDataAdd";
    }

    @GetMapping("/collData/editCollData")
    public String editCollData(@Param("id") int id, ModelMap map){
        CollData collData = collDataService.selectCollDataById(id);
        map.addAttribute("collData",collData);
        return "CollData/collDataEdit";
    }

    @ResponseBody
    @PostMapping("/collData/updateCollData")
    public int updateCollData(CollData collData){
        return collDataService.updateCollDateById(collData);
    }

    @ResponseBody
    @PostMapping("/collData/insertData")
    public int insertData(CollData collData){
        return collDataService.collData(collData);
    }

    @ResponseBody
    @GetMapping("/collData/selectAllCollData")
    public DataTable selectAllCollData(@RequestParam int page, int limit) {
        return DataTable.getTableData(collDataService.selectAllCollData(page, limit), collDataService.countCollData());
    }

    @ResponseBody
    @GetMapping("/collData/deleteCollDataByIds")
    public int deleteCollDataByIds(String collDataId) {
        return collDataService.deleteCollDataByIds(collDataId);
    }

    @ResponseBody
    @PostMapping("collData/addCollData")
    public int addCollData(CollData collData) {
        return collDataService.collData(collData);
    }
}
