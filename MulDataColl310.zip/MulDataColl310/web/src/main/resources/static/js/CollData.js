layui.use('table', function () {
    var $ = layui.jquery,
        table = layui.table,
        tableObj = table.render({}),
        form = layui.form,
        laydate = layui.laydate;

    table.render({
        elem: '#collDataList',
        id: 'collDataList',
        url: '/collData/selectAllCollData', //数据接口
        toolbar: "#toolbar",
        limit: 10,
        done: function(res) {
            console.log('后端返回的数据：', res.data);
        },
        initSort: {
            field: 'id',
            type: 'desc'
        },
        page: {
            // layout: ['prev', 'page', 'next','count', 'limit', 'refresh', 'skip'],
            limits: [5, 10, 15, 20]
        },
        even: true,
        skin: 'nob',
        // where: {
        //     username: '',
        //     sex: ''
        // },
        cols: [[ //佛系注释，为了避开thymeleaf语法检查
            {
                checkbox: true,
                fixed: 'left'
            },
            {
                field: 'id',
                title: '编号',
                width: 70
            },
            {
                field: 'distance',
                title: '距离',
                templet: function (d) {
                    return d.distance + "cm";
                }
            },
            {
                field: 'temperature',
                title: '温度',
                templet: function (d) {
                    return d.temperature + "℃";
                }
            },
            {
                field: 'humidity',
                title: '湿度',
                templet: function (d) {
                    return d.humidity + "%";
                }
            },
            {
                field: 'light',
                title: '光照强度',
                templet: function (e) {
                    return e.light + "mv";
                }
            },
            {
                field: 'GX',
                title: 'mpu6050采集数据',
                templet: function (d) {
                    return d.gx + "°";
                },
                done: function (e) {
                    console.log(e.data);
                }
            },
            {
                field: 'people',
                title: '人体',
                templet: function (d) {
                    if (d.people)
                        return "有人";
                    else
                        return "无人";
                }
            },
            {
                field: 'ip',
                title: 'IP地址',
            },
            {
                field: 'collTime',
                title: '采集时间',
                width: 180
            },
            {
                title: '操作',
                fixed: 'right',
                minWidth: 150,
                align: 'center',
                toolbar: '#tools'
            }
        ]]
    });

    //头工具栏事件
    table.on('toolbar(collDataList)', function (obj) {
        var checkStatus = table.checkStatus('collDataList'),
            layer = parent.layer === undefined ? layui.layer : top.layer;
        switch (obj.event) {
            case 'delete':
                var data = checkStatus.data;
                if (data.length > 0) {
                    layer.confirm('确认要删除这【' + data.length + '】条数据吗？', {icon: 3}, function (index) {
                        var ids = "";
                        for (var i = 0; i < data.length; i++) {
                            ids += data[i].id;
                            if (i !== data.length - 1)
                                ids += ',';
                        }
                        $.ajax({
                            type: "get",
                            url: "/collData/deleteCollDataByIds",
                            data: "collDataId=" + ids,
                            success: function (res) {
                                if (res > 0) {
                                    layer.close(index);
                                    layer.msg("已删除【" + data.length + "】条数据", {icon: 6});
                                    table.reload('collDataList');
                                }
                            },
                            error: function () {
                                layer.msg("系统错误", {icon: 2, anim: 6});
                            }
                        });
                    });
                } else {
                    layer.alert('请至少选择一条数据', {icon: 7, title: '警告'});
                }
                break;

            case 'add':
                layer.open({
                    type: 2,
                    title: '添加数据',
                    shadeClose: false,
                    shade: 0.8,
                    area: setPage(),
                    anim: 0,
                    content: '/collData/addCollData',
                    end: function () {
                        table.reload("collDataList");
                    }
                });
                break;
        }
    });

    function setPage() {
        if ($(window).width() < 458) {
            return ['100%', '100%'];
        } else {
            return ['30%', '90%'];
        }
    }

    //监听每行的工具条
    table.on('tool(collDataList)', function (obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
        var data = obj.data, //获得当前行数据
            layEvent = obj.event, //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            tr = obj.tr,

            //获得当前行 tr 的 DOM 对象（如果有的话）
            layer = parent.layer === undefined ? layui.layer : top.layer;

        if (layEvent === 'delete') { //删除
            layer.confirm('确定删除Id为【' + data.id + '】的数据吗？', function (index) {

                $.ajax({
                    type: "get",
                    url: "/collData/deleteCollDataByIds",
                    data: "collDataId=" + data.id,
                    success: function (data) {
                        if (data === 1) {
                            layer.msg("删除成功", {icon: 1, time: 2000});
                            obj.del();
                        } else {
                            layer.msg("删除失败！", {icon: 2, anim: 6});
                        }
                    },
                    error: function () {
                        layer.msg("系统错误！", {icon: 2, anim: 6});
                    }

                });
            });

        } else if (layEvent === 'edit') { //编辑
            layer.open({
                type: 2,
                title: '修改数据信息',
                shadeClose: false,
                shade: 0.8,
                area: setPage(1),
                anim: 0,
                content: '/collData/editCollData?id=' + data.id,
                end: function () {
                    table.reload("collDataList");
                }
            });
        }
    });

});
/*头部日期组件*/
layui.use('laydate', function () {
    var laydate = layui.laydate;

    //执行一个laydate实例
    laydate.render({
        elem: '#createTime', //指定元素
        format: 'yyyy-MM-dd HH:mm:ss', //可任意组合
        type: 'datetime',
        position: 'fixed'
    });
});

