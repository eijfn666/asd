package com.hunau.mapper;

import com.hunau.domain.CollData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author TanXY
 * @date 2020/12/29 - 18:34
 */
@Mapper
@Repository
public interface CollDataMapper {

    /**
     * 查询所有的数据
     * @author TanXY
     * @date 2020/12/29 18:56
     * @param page 页码
     * @param limit 每页数据量
     * @return java.util.List<CollData>
     */
    List<CollData> selectAllCollData(@Param("page") int page,@Param("limit") int limit);

    /**
     * 统计所有总数据条数，主要用于分页
     * @author TanXY
     * @date 2020/12/29 20:31
     * @return int
     */
    int countCollData();

    /**
     * 将采集的数据插入数据库,返回1表示插入成功，否则插入失败
     * @author TanXY
     * @date 2020/12/29 18:57
     * @param collData CollData实体对象
     * @return int
     */
    int collData(CollData collData);

    /**
     * 根据Id查询CollData
     * @author TanXY
     * @date 2020/12/30 0:03
     * @param id 数据id
     * @return int
     */
    CollData selectCollDataById(int id);

    /**
     * 根据Id更新采集的数据
     * @author TanXY
     * @date 2020/12/29 18:59
     * @param collData CollData实体对象
     * @return int
     */
    int updateCollDateById(CollData collData);

    /**
     * 根据Id批量删除数据
     * @author TanXY
     * @date 2020/12/29 19:01
     * @param id 要删除的数据编号数组
     * @return int
     */
    int deleteCollDataByIds(String[] id);
}
