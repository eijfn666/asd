package com.hunau.service;


import com.hunau.domain.User;

/**
 * @author TanXY
 */
public interface UserService {

    /**
     * 根据登录名称查询用户，主要用于登录校验
     * @author TanXY
     * @date 2021/1/1 13:54
     * @param loginName 登录名称
     * @return com.hunau.domain.User
     */
    User selectUserByName(String loginName);

    /**
     * 添加用户，主要用于注册
     * @author TanXY
     * @date 2021/1/1 13:55
     * @param user 用户对象
     * @return int
     */
    int addUser(User user);

    /**
     * 用于用户注册时生产随机盐
     * @author TanXY
     * @date 2021/1/1 14:01
     * @param len 随机盐的长度
     * @return java.lang.String
     */
    String randomSalt(int len);

}
