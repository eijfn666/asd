package com.hunau.service.impl;


import com.hunau.domain.CollData;
import com.hunau.mapper.CollDataMapper;
import com.hunau.service.CollDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author TanXY
 * @date 2020/12/29 - 18:37
 */
@Service
public class CollDataServiceImpl implements CollDataService {

    @Autowired
    CollDataMapper collDataMapper;

    @Override
    public List<CollData> selectAllCollData(int page, int limit) {
        page = (page - 1) * limit;
        return collDataMapper.selectAllCollData(page, limit);
    }


    @Override
    public int collData(CollData collData) {
        return collDataMapper.collData(collData);
    }

    @Override
    public CollData selectCollDataById(int id) {
        return collDataMapper.selectCollDataById(id);
    }

    @Override
    public int countCollData() {
        return collDataMapper.countCollData();
    }

    @Override
    public int updateCollDateById(CollData collData) {
        return collDataMapper.updateCollDateById(collData);
    }

    @Override
    public int deleteCollDataByIds(String ids) {
        String[] id = ids.split(",");
        return collDataMapper.deleteCollDataByIds(id);
    }
}
