package com.hunau.netty;

import com.hunau.domain.CollData;
import com.hunau.service.CollDataService;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.net.InetSocketAddress;

/**
 * @author TanXY
 * @date 2020/12/9 - 14:54
 */
@Component
public class NettyServerHandler extends ChannelInboundHandlerAdapter {
    /** 获取实例化对象 */
    @Autowired
    protected CollDataService dataService;

    private static NettyServerHandler serverHandler;

    /** 配合@Component注解获取service层的bean */
    @PostConstruct
    public void init(){
        serverHandler = this;
        serverHandler.dataService = this.dataService;
    }

    /**
     * 客户端连接会触发
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("客户端发起连接！！！！");
    }

    /**
     * 客户端发消息会触发
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        //获取客户端的IP
        InetSocketAddress inSocket = (InetSocketAddress)ctx.channel().remoteAddress();
        String ip = inSocket.getAddress().getHostAddress();

        //将RGB数据处理
        String str = msg.toString();

        System.out.println("服务器接收到客户端的数据--->" + msg.toString());

        CollData collData = new CollData();
        System.out.println("a");
        String[] data = str.split(",");

        collData.setLight(Integer.parseInt(data[0]));
        System.out.println("b");
        collData.setDistance(Float.parseFloat(data[1]));
        System.out.println("c");
        collData.setPeople("1".equals(data[2]));
        System.out.println("d");
        collData.setTemperature(Float.parseFloat(data[3]));
        System.out.println("e");
        collData.setHumidity(Float.parseFloat(data[4]));
        System.out.println("f");
        collData.setGX(Float.parseFloat(data[5]));
        System.out.println("g");
        collData.setIp(ip);
        //插入数据
        System.out.println("123");
        serverHandler.dataService.collData(collData);
        System.out.println("456");
        //调用业务层方法将数据写入数据库
//        ctx.write("#stop$");
//        ctx.flush();
    }

    /**
     * 发生异常触发
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("客户端连接断开！！！！！！！！");
    }
}
