package com.hunau.lang;

import lombok.Data;

import java.util.List;


/**
 * @author TanXY
 */
@Data
public class DataTable {
    private int code;

    private String msg;

    private List<?> data;

    private int count;

    public static DataTable getTableData(List<?> list, int size){
        DataTable resData = new DataTable();
        resData.setCode(0);
        resData.setData(list);
        resData.setCount(size);
        return resData;
    }
}
