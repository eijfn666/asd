package com.hunau.domain;

import lombok.Data;

/**
 * @author TanXY
 * @date 2020/12/29 - 18:29
 */
@Data
public class CollData {
    private long id;

    private float distance;

    private float temperature;

    private float humidity;

    private int light;

    private float GX;

    private Boolean people;

    private String ip;

    private String collTime;
}
